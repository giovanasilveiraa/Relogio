﻿namespace prjRelogio
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pbImagem = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pulso = new System.Windows.Forms.Timer(this.components);
            this.lbHorario = new System.Windows.Forms.Label();
            this.menu = new System.Windows.Forms.MenuStrip();
            this.mnArquivo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnArquivoMostrador = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pbImagem)).BeginInit();
            this.menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbImagem
            // 
            this.pbImagem.Location = new System.Drawing.Point(7, 37);
            this.pbImagem.Name = "pbImagem";
            this.pbImagem.Size = new System.Drawing.Size(498, 499);
            this.pbImagem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbImagem.TabIndex = 0;
            this.pbImagem.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "imagens|*.png";
            // 
            // pulso
            // 
            this.pulso.Interval = 1000;
            this.pulso.Tick += new System.EventHandler(this.pulso_Tick);
            // 
            // lbHorario
            // 
            this.lbHorario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbHorario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbHorario.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHorario.Location = new System.Drawing.Point(7, 562);
            this.lbHorario.Name = "lbHorario";
            this.lbHorario.Size = new System.Drawing.Size(498, 112);
            this.lbHorario.TabIndex = 1;
            this.lbHorario.Text = "00:00:00";
            this.lbHorario.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menu
            // 
            this.menu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnArquivo});
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(514, 24);
            this.menu.TabIndex = 2;
            this.menu.Text = "menuStrip1";
            // 
            // mnArquivo
            // 
            this.mnArquivo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnArquivoMostrador});
            this.mnArquivo.Name = "mnArquivo";
            this.mnArquivo.Size = new System.Drawing.Size(70, 20);
            this.mnArquivo.Text = "&ARQUIVO";
            // 
            // mnArquivoMostrador
            // 
            this.mnArquivoMostrador.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnArquivoMostrador.ForeColor = System.Drawing.Color.MidnightBlue;
            this.mnArquivoMostrador.Name = "mnArquivoMostrador";
            this.mnArquivoMostrador.Size = new System.Drawing.Size(163, 22);
            this.mnArquivoMostrador.Text = "MOSTRADORES";
            this.mnArquivoMostrador.Click += new System.EventHandler(this.mnArquivoMostrador_Click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(514, 686);
            this.Controls.Add(this.lbHorario);
            this.Controls.Add(this.pbImagem);
            this.Controls.Add(this.menu);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menu;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RELOGIO";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbImagem)).EndInit();
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbImagem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Timer pulso;
        private System.Windows.Forms.Label lbHorario;
        private System.Windows.Forms.MenuStrip menu;
        private System.Windows.Forms.ToolStripMenuItem mnArquivo;
        private System.Windows.Forms.ToolStripMenuItem mnArquivoMostrador;
    }
}

